function changeStyle(style,row){
    var element=document.getElementById('sentence'+row);
    switch(style){
        case 'bold':
            element.style.fontWeight=(element.style.fontWeight==='bold')?'normal':'bold';
            break;
        case 'italic':
            element.style.fontStyle=(element.style.fontStyle==='italic')?'normal':'italic';
            break;
        case 'underline':
            var currentDec=getComputedStyle(element).textDecoration;
            element.style.textDecoration=(currentDec.includes('underline'))?'none':'underline';
            break;
    }
}
function font(row,size){
    var element=document.getElementById('sentence'+row);
    element.style.fontSize=size+"px";
}
function color(row,color){
    var element=document.getElementById('sentence'+row);
    element.style.color=color;
}